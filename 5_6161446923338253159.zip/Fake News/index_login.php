<?php
	//Start session
	session_start();
	
	include('connect/db.php');
		
	//Sanitize the POST values
	$username = $_POST['username'];
	$password = $_POST['password'];
	//Create query
	$qrya= $db->prepare("SELECT * FROM admin WHERE username='$username' AND password='$password'");
	$qrya->execute();
	$counta = $qrya->rowcount();
	
	//Check whether the query was successful or not
	if($counta > 0) {
		//Login Successful
		session_regenerate_id();
		$rowa = $qrya->fetch();
		$_SESSION['SESS_ADMIN_ID'] = $rowa['admin_id'];
		session_write_close();
		header("location: apps/index.php");
		exit();
	}	
	else 
	{
		//Login failed
		echo "<script>alert('Check Username And Password'); window.location='index.php'</script>";
		exit();
	}
?>
