<?php
	include("auth.php");
	include('../connect/db.php');
	$admin_id=$_SESSION['SESS_ADMIN_ID'];
	$result = $db->prepare("select * from admin where admin_id='$admin_id'");
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++)
	{		
		$username=$row["username"];
		$password=$row["password"];	
	}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  	<?php include("include/header.php");?>
</head>

<body class="">
  <div class="wrapper ">
    <?php include("include/leftmenu.php");?>
    <div class="main-panel">
      <!-- Navbar -->
      <?php include("include/navbar.php");?>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-8">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Edit Profile</h4>
                  <p class="card-category">Complete your profile</p>
                </div>
                <div class="card-body">
                  <form action="action/profile_update.php" method="post" autocomplete="off">                 
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">Username</label>
                            <input type="hidden"  name="admin_id" value="<?php echo $admin_id;?>">
                          <input type="text" class="form-control" name="username" value="<?php echo $username?>" disabled>
                        </div>
                      </div>
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">Password</label>
                          <input type="text" class="form-control" name="password" value="<?php echo $password?>">
                        </div>
                      </div>                      
                    </div>                   
                    <button type="submit" class="btn btn-primary pull-right">Update Profile</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>          
          </div>
        </div>
      </div>
       <?php include("include/footer.php");?> 
    </div>
  </div>
    <?php include("include/js.php");?>
</body>

</html>