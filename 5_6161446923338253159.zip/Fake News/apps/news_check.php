<?php
	include("auth.php");
	include('../connect/db.php');
	$abt=trim($_GET["abt"]);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  	<?php include("include/header.php");?>
</head>

<body class="">
  <div class="wrapper ">
    <?php include("include/leftmenu.php");?>
    <div class="main-panel">
      <!-- Navbar -->
      <?php include("include/navbar.php");?>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-8">
            	<?php					
						$qry = $db->prepare("select * from news where text='$abt'");
						$qry->execute();
						$count = $qry->rowcount();
						if($count > 0) 
						{
				?>
                      <div class="card">
                        <div class="card-header card-header-danger">
                          <h4 class="card-title">Check Result</h4>
                          <p class="card-category">The News Is Fake</p>
                        </div>
                        <div class="card-body">
                        </div>
                      </div>
                <?php
					}
					else
					{						
				?>   
                	 <div class="card">
                        <div class="card-header card-header-success">
                          <h4 class="card-title">Check Result</h4>
                          <p class="card-category">The News Is Orginal</p>
                        </div>
                        <div class="card-body">
                        </div>
                      </div>
                <?php
					}
					?>
            </div>
            
            <div class="col-md-4">
              <div class="card card-profile">              
                <div class="card-body">                  
                  <a href="news.php" class="btn btn-danger btn-round">Back</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
       <?php include("include/footer.php");?> 
    </div>
  </div>
    <?php include("include/js.php");?>
</body>

</html>