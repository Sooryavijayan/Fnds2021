<?php
include("../../connect/db.php");

	
	$admin_id=$_POST["admin_id"];

	
	$password=$_POST["password"];
	
	
	if($password=="")
	{	
	}
	else
	{
		$sql = "update admin set password='$password' where admin_id='$admin_id'";
		$q1 = $db->prepare($sql);
		$q1->execute();
	}

	header("location:../index.php");
?>
