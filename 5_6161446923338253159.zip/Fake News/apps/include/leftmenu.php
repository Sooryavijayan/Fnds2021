 <div class="sidebar" data-color="purple" data-background-color="white" data-image="assets/img/sidebar-1.jpg">      
        <div class="logo">
          <a href="index.php" class="simple-text logo-normal">
                News Check
          </a>
       </div>
       <div class="sidebar-wrapper">
        <ul class="nav">          
          <li class="nav-item ">
            <a class="nav-link" href="profile.php">
              <i class="fa fa-book"></i>
              <p>Profile</p>
            </a>
          </li>
                  
          <li class="nav-item ">
            <a class="nav-link" href="news.php">
              <i class="fa fa-book"></i>
              <p>News</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="fact.php">
              <i class="fa fa-book"></i>
              <p>Analyze</p>
            </a>
          </li>   
          
           <li class="nav-item ">
            <a class="nav-link" href="../index.php">
              <i class="fa fa-book"></i>
              <p>Logout</p>
            </a>
          </li>                  
        </ul>
      </div>
</div>