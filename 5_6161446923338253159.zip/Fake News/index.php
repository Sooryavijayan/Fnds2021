<!DOCTYPE html>
<html lang="zxx">
<head>
<title>Fact Checker</title>
<!-- Meta-Tags -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Secured Transfer For Stego Vision" />

<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" /><!--bootstrap-css-->
<link href="fonts/css/font-awesome.css" rel="stylesheet"> <!--font-awesome-css-->
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" /><!--flexslider-css-->
<link href="css/circles.css" rel="stylesheet" type="text/css" media="all" /><!--skill-circles-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /><!--style-sheet-->
<link href='css/aos.css' rel='stylesheet prefetch' type="text/css" media="all" /><!--Animation-effects-css-->

</head>
<body>

<!--banner start here-->
<div class="banner" id="home">
<div class="agileinfo-dot">
   <div class="header">
		   <div class="header-main">
			 <div class="header-top-agileits">
		   	 <div class="container">
				<div class="w3l-social" data-aos="fade-right">
					<ul>
						<li><a href="#"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
					</ul>
				</div>
				<ul class="agile_forms" data-aos="fade-left">
<li><a class="active" href="#" data-toggle="modal" data-target="#login"><i class="fa fa-sign-in" aria-hidden="true"></i> Login</a> </li>
				</ul>
				<div class="clearfix"> </div>
				</div>
			</div>		   
		   </div>
		<div class="container">
		   <div class="banner-bottom">
		   	   <section class="slider">
				 <div class="flexslider">
					<ul class="slides">
					  <li>
					  	<div class="banner-bottom-text">
					  			<h3>Get around the clock support from experts</h3>
					 	</div>
					  </li>
					  <li>
					  	<div class="banner-bottom-text">
					  		<h3>Run and check in just a few easy steps</h3>
					 	</div>
					  </li>
					  <li>
					  	<div class="banner-bottom-text">
					  			<h3>Get around the clock support from  experts</h3>
					 	</div>
					  </li>
					  <li>
					  	<div class="banner-bottom-text">
					  		<h3>Run check fact in just few easy steps</h3>
					 	</div>
					  </li>			  
				    </ul>
				 </div>
				 <div class="clearfix"> </div>
		      </section>
			<div class="thim-click-to-bottom">
				<a href="#about" class="scroll">
					<i class="fa fa-chevron-down" aria-hidden="true"></i>
				</a>
			</div>
		   </div>
		</div>
	</div>
</div>
</div>
<!--banner end here-->

	<!-- Admin -->
		<div class="modal fade" id="login" tabindex="-1" role="dialog">
            <div class="modal-dialog">
            <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        
                        <div class="signin-form profile">
                        <h3 class="agileinfo_sign">Login</h3>	
                                <div class="login-form">
                                    <form action="index_login.php" method="post" autocomplete="off">
                                        <input type="text" name="username" placeholder="Username" required="">
                                        <input type="password" name="password" placeholder="Password" required="">
                                        <div class="tp">
                                            <input type="submit" value="Login">
                                        </div>                                      
                                    </form>
                                </div>
                                <div class="login-social-grids">
                                    <ul>
                                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-rss"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
        
              

<!--banner bottom-->
<div class="banner-btm-w3layouts" id="about">
	<div class="container">
	<!---728x90--->

	<div class="tittle-agileinfo">
		<span>01</span>
		<h2>Welcome to Fact Checker</h2>
		<p >Suspendisse fringilla pellentesque risus sit amet bibendum.</p>
	</div>
	<!---728x90--->

		<div class="about-main">
		<div class="col-md-4 about-grids" data-aos="zoom-in">
			<i class="fa fa-bookmark-o" aria-hidden="true"></i>
			<h3 class="subheading-agileits-w3layouts">News Fact & Checking</h3>
			<p class="para-agileits-w3layouts">Duis sit amet nisi quis leo fermentum vestibulum vitae eget augue. Sed feugiat quam nec mauris mattis malesuada.</p>
		</div>
		<div class="col-md-4 about-grids" data-aos="zoom-in">
			<i class="fa fa-handshake-o" aria-hidden="true"></i>
			<h3 class="subheading-agileits-w3layouts">Actual News Fack Check</h3>
			<p class="para-agileits-w3layouts">Duis sit amet nisi quis leo fermentum vestibulum vitae eget augue. Sed feugiat quam nec mauris mattis malesuada.</p>
		</div>
		<div class="col-md-4 about-grids" data-aos="zoom-in">
			<i class="fa fa-money" aria-hidden="true"></i>
			<h3 class="subheading-agileits-w3layouts">Growth & Check Access</h3>
			<p class="para-agileits-w3layouts">Duis sit amet nisi quis leo fermentum vestibulum vitae eget augue. Sed feugiat quam nec mauris mattis malesuada.</p>
		</div>
		<div class="clearfix"> </div>	
		</div>
	</div>
</div>

<!--//banner bottom-->

<!-- newsletter -->
<div class="agileits_w3layouts newsletter" id="contact">	
</div>
<!-- //newsletter -->

<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script src="js/main.js"></script>	
<script defer src="js/jquery.flexslider.js"></script>
<script type="text/javascript">
	$(function(){				 
	});
	$(window).load(function(){
	  $('.flexslider').flexslider({
		animation: "slide",
		start: function(slider){
		  $('body').removeClass('loading');
		}
	  });
	});
</script>
<!-- FlexSlider -->
<!-- clients-slider-script -->
<script src="js/slideshow.min.js"></script>
<script src="js/launcher.js"></script>
<!-- //clients-slider-script -->
<script src="js/jzBox.js"></script>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
<!-- smooth scrolling -->
	<script type="text/javascript">
		$(document).ready(function() {
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
<!-- Animation-effect -->
<script src='js/aos.js'></script>
<script src="js/aosindex.js"></script>
<!-- //Animation-effect -->
	<a href="#home" class="scroll" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!-- //smooth scrolling -->
<script src="js/bootstrap.js"></script>
</body>
</html>