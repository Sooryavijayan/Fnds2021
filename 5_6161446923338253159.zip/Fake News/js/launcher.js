/*
	Start the slideshow
	----------------------------------- */

	// Create and initialise the slideshow
	new CRD.Slideshow({ slideshow: '#slideshow' }).init();